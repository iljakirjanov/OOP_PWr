#include <string>

class Circle{
	private:
		double radius;
		std::string color;
	public:
		Circle();
		Circle(double rad);
		double getArea();
		std::string getColor();
		double getRadius();
		void setRadius(double rad);
		void setColor(std::string clr);
		void describe();
		Circle * compareArea(Circle & circle);
};
