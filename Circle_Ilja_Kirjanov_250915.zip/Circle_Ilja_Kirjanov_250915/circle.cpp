#include "circle.h"
#include <string>
#include <iostream>

Circle:: Circle(){
radius = 0;
color = "white";}

Circle:: Circle(double rad){
radius = rad;
color = "white";}

double Circle:: getArea(){
return 3.14*radius*radius;}

std::string Circle:: getColor(){
return color;}

double Circle:: getRadius(){
return radius;}

void Circle:: setRadius(double rad){
radius = rad;}

void Circle:: setColor(std::string clr){
color = clr;}

void Circle:: describe(){
std::cout<<color<< " with radius "<<radius<<std::endl;}

Circle * Circle:: compareArea(Circle & circle){
if(this->getArea()>circle.getArea()){
	return this;}
else if(this->getArea()<circle.getArea()){
	return & circle;}
}


