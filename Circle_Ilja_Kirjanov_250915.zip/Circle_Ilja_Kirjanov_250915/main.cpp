#include <stdio.h>
#include <string>
#include <iostream>
#include "circle.h"


int main(void){
	int size;
	printf("How many ball you want to allocate? ");
	scanf("%d", &size);
	Circle * dynamic_array=NULL;
	dynamic_array = new Circle[size];

	double rad;

	for(int i=0;i<size;i++){
		printf("\n Choose Ball %d radius----(press -1 to define by default contructor)----:\n", i+1);
		scanf("%lf", &rad);
		if(rad==-1){
			dynamic_array[i] = Circle();
		}else{
			dynamic_array[i] = Circle(rad);
		}
	}
	for (int i=0;i<size;i++){
		printf("Ball %d: ", i+1);
		dynamic_array[i].describe();
	}

	delete[] dynamic_array;
	return 0;
}
